#!/usr/env/bin python3
# File: app/model/destination.py
# Author: Oluwatobiloba Light
# Date created: 23/04/2025
"""Destinations model"""


from typing import List
from sqlalchemy import Column, String
from app.model.base_model import BaseModel
from sqlmodel import Field, Relationship


class Destination(BaseModel, table=True):
    __tablename__: str = "destinations"

    name: str = Field(sa_column=Column("name",
                                       String(255), default=None, nullable=False, unique=True))
    
    regions: List["Region"] = Relationship(back_populates="destination")
