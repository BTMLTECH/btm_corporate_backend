#!/usr/bin/env python3
# File: package.py
# Author: Oluwatobiloba Light
"""Tour Package Model"""

from typing import Optional, List
from sqlalchemy import Column, String, Text, Integer, Float
from sqlmodel import Field, Relationship
from app.model.base_model import BaseModel


class TourPackage(BaseModel, table=True):
    __tablename__: str = "tour_packages"

    title: str = Field(sa_column=Column(String(255), nullable=False))
    slug: str = Field(sa_column=Column(String(255), nullable=False, unique=True))
    description: Optional[str] = Field(default=None, sa_column=Column(Text))
    
    duration_days: int = Field(sa_column=Column(Integer, nullable=False))
    duration_nights: int = Field(sa_column=Column(Integer, nullable=False))
    
    price_per_person_usd: float = Field(sa_column=Column(Float, nullable=False))
    destinations: List[str] = Field(sa_column=Column(Text), default=[])
    
    accommodation_details: Optional[str] = Field(default=None, sa_column=Column(Text))
    meals_included: Optional[str] = Field(default=None, sa_column=Column(Text))
    
    transport_info: Optional[str] = Field(default=None, sa_column=Column(Text))
    itinerary: Optional[str] = Field(default=None, sa_column=Column(Text))
    inclusions: Optional[str] = Field(default=None, sa_column=Column(Text))

    package_type: str = Field(sa_column=(Column(String(50), nullable=False)))
    
    # contact_phone: Optional[str] = Field(default=None, sa_column=Column(String(50)))
    # contact_email: Optional[str] = Field(default=None, sa_column=Column(String(100)))

    # ForeignKey relationship (Many packages can belong to one region)
    # region_id: Optional[str] = Field(default=None, foreign_key="regions.id")
    # region: Optional["Region"] = Relationship(back_populates="tour_packages")
