verification_style = """
<style media="all" type="text/css">
    /* -------------------------------------
    GLOBAL RESETS
------------------------------------- */
    
    body {
      font-family: Helvetica, sans-serif;
      -webkit-font-smoothing: antialiased;
      font-size: 16px;
      line-height: 1.3;
      -ms-text-size-adjust: 100%;
      -webkit-text-size-adjust: 100%;
    }
    
    table {
      border-collapse: separate;
      mso-table-lspace: 0pt;
      mso-table-rspace: 0pt;
      width: 100%;
    }
    
    table td {
      font-family: Helvetica, sans-serif;
      font-size: 16px;
      vertical-align: top;
    }
    /* -------------------------------------
    BODY & CONTAINER
------------------------------------- */
    
    body {
      background-color: #f4f5f6;
      margin: 0;
      padding: 0;
    }
    
    .body {
      background-color: #f4f5f6;
      width: 100%;
    }
    
    .container {
      margin: 0  !important;
      max-width: 100%;
      padding: 0;
      padding-top: 24px;
      width: 100%;
    }
    
    .content {
      box-sizing: border-box;
      display: block;
      margin: 0;
      max-width: 100%;
      padding: 0;
    }
    /* -------------------------------------
    HEADER, FOOTER, MAIN
------------------------------------- */
    
    .main {
      background: #ffffff;
      border: 1px solid #eaebed;
      border-radius: 16px;
      width: 100%;
    }
    
    .wrapper {
      box-sizing: border-box;
      padding: 24px;
    }
    
    .footer {
      clear: both;
      padding-top: 24px;
      text-align: center;
      width: 100%;
    }
    
    .footer td,
    .footer p,
    .footer span,
    .footer a {
      color: #9a9ea6;
      font-size: 16px;
      text-align: center;
    }
    /* -------------------------------------
    TYPOGRAPHY
------------------------------------- */
    
    p {
      font-family: Helvetica, sans-serif;
      font-size: 16px;
      font-weight: normal;
      margin: 0;
      margin-bottom: 16px;
    }
    
    a {
      color: #0867ec;
      text-decoration: underline;
    }
    /* -------------------------------------
    BUTTONS
------------------------------------- */
    
    .btn {
      box-sizing: border-box;
      min-width: 100% !important;
      width: 100%;
    }
    
    .btn > tbody > tr > td {
      padding-bottom: 16px;
    }
    
    .btn table {
      width: auto;
    }
    
    .btn table td {
      background-color: #ffffff;
      border-radius: 4px;
      text-align: center;
    }
    
    .btn a {
      background-color: #ffffff;
      border: solid 2px #0867ec;
      border-radius: 4px;
      box-sizing: border-box;
      color: #0867ec;
      cursor: pointer;
      display: inline-block;
      font-size: 16px;
      font-weight: bold;
      margin: 0;
      padding: 12px 24px;
      text-decoration: none;
      text-transform: capitalize;
    }
    
    .btn-primary table td {
      background-color: #0867ec;
    }
    
    .btn-primary a {
      background-color: #0867ec;
      border-color: #0867ec;
      color: #ffffff;
    }
    
    @media all {
      .btn-primary table td:hover {
        background-color: #ec0867 !important;
      }
      .btn-primary a:hover {
        background-color: #ec0867 !important;
        border-color: #ec0867 !important;
      }
    }
    
    /* -------------------------------------
    OTHER STYLES THAT MIGHT BE USEFUL
------------------------------------- */
    
    .last {
      margin-bottom: 0;
    }
    
    .first {
      margin-top: 0;
    }
    
    .align-center {
      text-align: center;
    }
    
    .align-right {
      text-align: right;
    }
    
    .align-left {
      text-align: left;
    }
    
    .text-link {
      color: #0867ec !important;
      text-decoration: underline !important;
    }
    
    .clear {
      clear: both;
    }
    
    .mt0 {
      margin-top: 0;
    }
    
    .mb0 {
      margin-bottom: 0;
    }
    
    .preheader {
      color: transparent;
      display: none;
      height: 0;
      max-height: 0;
      max-width: 0;
      opacity: 0;
      overflow: hidden;
      mso-hide: all;
      visibility: hidden;
      width: 0;
    }
    
    .powered-by a {
      text-decoration: none;
    }
    
    /* -------------------------------------
    RESPONSIVE AND MOBILE FRIENDLY STYLES
------------------------------------- */
    
    @media only screen and (max-width: 640px) {
      .main p,
      .main td,
      .main span {
        font-size: 16px !important;
      }
      .wrapper {
        padding: 8px !important;
      }
      .content {
        padding: 0 !important;
      }
      .container {
        padding: 0 !important;
        padding-top: 8px !important;
        width: 100% !important;
      }
      .main {
        border-left-width: 0 !important;
        border-radius: 0 !important;
        border-right-width: 0 !important;
      }
      .btn table {
        max-width: 100% !important;
        width: 100% !important;
      }
      .btn a {
        font-size: 16px !important;
        max-width: 100% !important;
        width: 100% !important;
      }
    }
    /* -------------------------------------
    PRESERVE THESE STYLES IN THE HEAD
------------------------------------- */
    
    @media all {
      .ExternalClass {
        width: 100%;
      }
      .ExternalClass,
      .ExternalClass p,
      .ExternalClass span,
      .ExternalClass font,
      .ExternalClass td,
      .ExternalClass div {
        line-height: 100%;
      }
      .apple-link a {
        color: inherit !important;
        font-family: inherit !important;
        font-size: inherit !important;
        font-weight: inherit !important;
        line-height: inherit !important;
        text-decoration: none !important;
      }
      #MessageViewBody a {
        color: inherit;
        text-decoration: none;
        font-size: inherit;
        font-family: inherit;
        font-weight: inherit;
        line-height: inherit;
      }
    }
    </style>
"""

# email_content = f"""
# <!DOCTYPE html>
# <html lang="en">
# <head>
#     <meta charset="UTF-8">
#     <meta name="viewport" content="width=device-width, initial-scale=1.0">
#     <title>Confirm Your BTM Ghana Registration</title>
#     {verification_style}
# </head>
# <body>
#     <table role="presentation" border="0" cellpadding="0" cellspacing="0" class="body">
#       <tr>
#         <td>&nbsp;</td>
#         <td class="container">
#           <div class="content">

#             <!-- START CENTERED WHITE CONTAINER -->
#             <span class="preheader">Complete your BTM Ghana registration by verifying your email.</span>
#             <table role="presentation" border="0" cellpadding="0" cellspacing="0" class="main">

#               <!-- START MAIN CONTENT AREA -->
#               <tr>
#                 <td class="wrapper">
#                   <p>Hi, {name},</p>
#                   <p>We are happy you signed up for <strong>BTM Ghana</strong>!</p>
#                   <p>To complete your registration, please click on the link below to verify your email address:</p>
#                   <table role="presentation" border="0" cellpadding="0" cellspacing="0" class="btn btn-primary">
#                     <tbody>
#                       <tr>
#                         <td align="left">
#                           <table role="presentation" border="0" cellpadding="0" cellspacing="0">
#                             <tbody>
#                               <tr>
#                                 <td>
#                                   <a href="{verification_link}" target="_blank">Verify Email Address</a>
#                                 </td>
#                               </tr>
#                             </tbody>
#                           </table>
#                         </td>
#                       </tr>
#                     </tbody>
#                   </table>
#                   <p>This link will expire in <strong>{expiration_minutes}</strong> minutes. If you didn't request this email, please ignore it.</p>
#                   <p>Best regards,<br>BTM Ghana</p>
#                   <p><a href="https://btmghana.net" class="link">www.btmghana.net</a></p>
#                 </td>
#               </tr>

#               <!-- END MAIN CONTENT AREA -->
#             </table>

#             <!-- START FOOTER -->

#             <!-- END FOOTER -->

#           </div>
#         </td>
#         <td>&nbsp;</td>
#       </tr>
#     </table>
#   </body>
# </html>
# """

verification_style_2 = """
<style>
 body {{
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f9f5ff;
      color: #333;
    }}
    .container {{
      max-width: 600px;
      margin: 0 auto;
      padding: 20px;
    }}
    .logo-container {{
      text-align: center;
      margin-bottom: 24px;
    }}
    .logo {{
      background-color: #2e1065;
      border-radius: 50%;
      padding: 16px;
      display: inline-block;
    }}
    .header {{
      text-align: center;
      margin-bottom: 32px;
    }}
    h1 {{
      color: #2e1065;
      font-size: 24px;
      margin-bottom: 8px;
    }}
    .button-container {{
      text-align: center;
      margin: 24px 0;
    }}
    .button {{
      background-color: #2563eb;
      color: white;
      padding: 12px 24px;
      border-radius: 6px;
      text-decoration: none;
      font-weight: 500;
      display: inline-block;
    }}
    .footer {{
      text-align: center;
      font-size: 14px;
      color: #666;
      margin-top: 32px;
    }}
    
  </style>
"""


def verification_email_content_gen(
    name: str, verification_link: str, expiration_minutes: str
):
    return f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirm Your BTM Ghana Registration</title>
    {verification_style}
</head>
<body>
    <table role="presentation" border="0" cellpadding="0" cellspacing="0" class="body">
      <tr>
        <td>&nbsp;</td>
        <td class="container">
          <div class="content">

            <!-- START CENTERED WHITE CONTAINER -->
            <span class="preheader">Complete your BTM Ghana registration by verifying your email.</span>
            <table role="presentation" border="0" cellpadding="0" cellspacing="0" class="main">

              <!-- START MAIN CONTENT AREA -->
              <tr>
                <td class="wrapper">
                  <p>Hi, {name},</p>
                  <p>We are happy you signed up for <strong>BTM Ghana</strong>!</p>
                  <p>To complete your registration, please click on the link below to verify your email address:</p>
                  <table role="presentation" border="0" cellpadding="0" cellspacing="0" class="btn btn-primary">
                    <tbody>
                      <tr>
                        <td align="left">
                          <table role="presentation" border="0" cellpadding="0" cellspacing="0">
                            <tbody>
                              <tr>
                                <td>
                                  <a href="{verification_link}" target="_blank">Verify Email Address</a>
                                </td>
                              </tr>
                            </tbody>
                          </table>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <p>This link will expire in <strong>{expiration_minutes}</strong> minutes. If you didn't request this email, please ignore it.</p>
                  <p>Best regards,<br>BTM Ghana</p>
                  <p><a href="https://btmghana.net" class="link">www.btmghana.net</a></p>
                </td>
              </tr>

              <!-- END MAIN CONTENT AREA -->
            </table>

            <!-- START FOOTER -->
            
            <!-- END FOOTER -->

          </div>
        </td>
        <td>&nbsp;</td>
      </tr>
    </table>
  </body>
</html>
"""
