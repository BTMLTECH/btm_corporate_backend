

from pydantic import BaseModel


class GoogleSchema(BaseModel):
    state: str
